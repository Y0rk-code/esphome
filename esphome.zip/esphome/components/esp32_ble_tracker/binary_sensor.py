import esphome.config_validation as cv

CONFIG_SCHEMA = cv.invalid("This platform has been renamed to ble_presence in 1.13")
