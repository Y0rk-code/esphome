CODEOWNERS = ['@esphome/core']
