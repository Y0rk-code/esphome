import esphome.codegen as cg

CODEOWNERS = ['@OttoWinter']
homeassistant_ns = cg.esphome_ns.namespace('homeassistant')
